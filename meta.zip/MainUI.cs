using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum BTNType
{
Start,
Option,
Sound,
Back,
Quit
}

public class MainUI : MonoBehaviour
{
    
}
