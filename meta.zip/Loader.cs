using System.Collections;
using Unity.Loading;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Loader : MonoBehaviour
{
    public GameObject loadingScreen;
    public Slider loadingBar;
    public void LoadScene (int levelIndex)
    {
        StartCoroutine(LoadAsynchronously(levelIndex));
    }

    IEnumerator LoadAsynchronously(int levelIndex)
    {
        AsyncOperation operation = SceneManager.LoadSceneAsync(levelIndex);
        loadingScreen.SetActive(true);
        while (!operation.isDone)
        {
            float loadingBarValue = Mathf.Clamp01(operation.progress / 100f);
            loadingBar.value = loadingBarValue;
            yield return null;
        }
    }


}
