using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    [Header("------ Audio Source ------")]
    [SerializeField] AudioSource musicSource;
    [SerializeField] AudioSource EfSource;

    [Header("------ Audio Clip ------")]
    public AudioClip background;
    public AudioClip CorrectAnswer;
    public AudioClip WrongAnswer;

    public Sound[] MusicSounds, EfSounds;
    public AudioSource MusicSource;

    void Start()
    {
        musicSource.clip = background;
        musicSource.Play();
    }

    public void PlayEf(AudioClip clip)
    {
        EfSource.PlayOneShot(clip);
    }
    void Update()
    {
        
    }
}
