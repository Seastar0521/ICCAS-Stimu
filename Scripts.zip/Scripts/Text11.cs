using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Text11 : MonoBehaviour
{
    int a = 5;
    public UnityEngine.UI.Text mainText;

    public void myOnClick()
    {
        mainText.text = "Which button is Red?";
    }
   
    void Start()
    {
        mainText.text = "Level 1 is a round of color.\r\nChoose the color,\r\nwhich is written in the given question.";
    }

}
