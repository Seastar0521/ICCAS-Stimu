using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ChangeImage : MonoBehaviour
{
    public Image oldImage;
    public Sprite newImage;
    private ScoreManager ScoreManager;
    
    private void Start()
    {
        ScoreManager = ScoreManager.Instance;
    }

    private void Update()
    {
        
    }
    public void ImageChange(Button button)
    {
        string fileName = newImage.name;
        oldImage.sprite = newImage;
        button.interactable = false;
        button.transition = Selectable.Transition.None;


        if(fileName == "BlueCircle")
        {
            Debug.Log("BlueCircle");
        } 
        else
        {
            string sceneName = SceneManager.GetActiveScene().name;
            string levelString = sceneName.Split(' ')[0];
            Debug.Log("levelString :" + levelString + ", sceneName :" + sceneName);
            ScoreManager.AddIncorrectCount(levelString);
            Debug.Log(ScoreManager.GetIncorrectCount(levelString));
        }
    }

}
