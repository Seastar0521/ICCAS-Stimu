using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class RegisterSceneChanger : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {
    }
    
    public void OnLoginButtonClick()
    {
        Debug.Log("OnLogin()");
        SceneManager.LoadScene("Login");
    }

    public void OnSignUpButtonClick()
    {
        Debug.Log("OnSignUp()");
        SceneManager.LoadScene("Registration");
    }
}
