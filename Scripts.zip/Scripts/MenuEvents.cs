/*using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;
using UnityEngine.UI;

public class MenuEvents : MonoBehaviour
{
    public Slider MusicSlider;
    public AudioMixer mixer;
    public void SetMusic()
    {
        mixer.SetFloat("music", MusicSlider.value);
        
    }

    /*public void LoadLevel(int index);
    {
    SceneManager.LoadScene(index);
    }
}*/
