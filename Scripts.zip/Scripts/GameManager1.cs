using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager1 : MonoBehaviour
{
    public AudioSource bgmPlayer;
    
    void Start()
    {
        if (bgmPlayer != null)
        {
            bgmPlayer.Play();
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
