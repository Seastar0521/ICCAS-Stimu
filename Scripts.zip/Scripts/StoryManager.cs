using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class StoryManager : MonoBehaviour
{
    public GameObject nextBtn;
    public TextMeshProUGUI text;
    private List<string> _story = new List<string>();
    private int _storyNum;

   public int CharPerSeconds;
    string targetmsg;
    int index;
    float interval;
    bool isEffect;

    void Start()
    {
        _story.Add("1");
        _story.Add("hello world2");
        _story.Add("hello world3");
        _storyNum = 0;
        NextStory();
        //interval = 1.0f / CharPerSeconds;
    }

    public void NextStory()
    {
        if (_storyNum == 5)
        {
            SceneManager.LoadScene("");
        }
        //Setmsg(_story[_storyNum]);
        text.text = _story[_storyNum];
        _storyNum++;
    }
}

    /*void Setmsg(string msg)
    {
        if (isEffect)
        {
            CancelInvoke();
            EffectEnd();
        }

        targetmsg = msg;
        EffectStart();
    }

    void EffectStart()
    {
        text.text = "";
        index = 0;
        isEffect = true;
        Invoke("Effecting", interval);
    }
    void Effecting()
    {
        if (text.text == targetmsg)
        {
            EffectEnd();
            return;
        }
        text.text += targetmsg[index];
        index++;
        Invoke("Effecting", interval);
    }

    void EffectEnd()
    {
        isEffect = false;
    }
}*/
   