using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Level4 : MonoBehaviour
{
    // Start is called before the first frame update
    public void Level4Btn()
    {
        switch (this.gameObject.name)
        {
            case "Bretzel":
                SceneManager.LoadScene("LevelSelect");
                break;
            case "Cheese":
                SceneManager.LoadScene("Option");
                break;
        }
    }
}




