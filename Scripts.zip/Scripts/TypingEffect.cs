using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TypingEffect : MonoBehaviour
{

    public Text tx;
    private string m_text= "Hello!\n We are Jack & Rose."+ "   "+ "\nWe are here to assist your game." + "\nChoose the level depending on your ability." + "   "+
 ":)";
    
    void Start()
    {
        StartCoroutine(_typing());
        
    }

    IEnumerator _typing()
    {
/*        yield return new WaitForSeconds(2f);*/
        for(int i=0; i<= m_text.Length;i++)
        {
            tx.text = m_text.Substring(0, i);
            yield return new WaitForSeconds(0.03f);
        }
    }
    void Update()
    {
        
    }
}
