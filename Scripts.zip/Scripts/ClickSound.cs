using UnityEngine;
using System.Collections.Generic;

public class ClickSound : MonoBehaviour
{
    private static ClickSound instance;
    public static ClickSound Instance { get { return instance; } }

    private AudioSource audioSource;

    public Dictionary<string, AudioClip> buttonSounds = new Dictionary<string, AudioClip>();

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this.gameObject);
        }
        else
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
            audioSource = GetComponent<AudioSource>();

            // ��ư�� ȿ������ ���� (���⼭�� "Button1", "Button2"�� ���� ���ڿ��� AudioClip�� ����)
            buttonSounds.Add("Button1", Resources.Load<AudioClip>("Sound/DM-CGS-26"));
            buttonSounds.Add("Play", Resources.Load<AudioClip>("Sound/DM-CGS-24"));
            buttonSounds.Add("Button2", Resources.Load<AudioClip>("Sound/DM-CGS-44"));
            buttonSounds.Add("Next 1-1", Resources.Load<AudioClip>("Sound/DM-CGS-45"));
            buttonSounds.Add("Next", Resources.Load<AudioClip>("Sound/DM-CGS-44"));
            buttonSounds.Add("Start", Resources.Load<AudioClip>("Sound/SFX_UI_Click_Designed_Pop_Plastic_Crispy_Generic_1"));
            buttonSounds.Add("Quit", Resources.Load<AudioClip>("Sound/SFX_UI_Click_Designed_Pop_Plastic_Crispy_Generic_1"));
            buttonSounds.Add("Option", Resources.Load<AudioClip>("Sound/SFX_UI_Click_Designed_Pop_Thick_Generic_1"));
            buttonSounds.Add("Pause", Resources.Load<AudioClip>("Sound/SFX_UI_Click_Designed_Pop_Thick_Generic_1"));
            buttonSounds.Add("Sound", Resources.Load<AudioClip>("Sound/SFX_UI_Click_Designed_Pop_Thick_Generic_1"));
            buttonSounds.Add("Home", Resources.Load<AudioClip>("Sound/SFX_UI_Click_Designed_Pop_Thick_Generic_1"));

        }
    }        //���� �� ��ƽ ū�� �ö�ƽ ȭ��ǥ 44 �ؽ�Ʈ�� 45 Ʋ�� �Ҹ� 24 ���� �Ҹ� 26 

    public void PlayButtonSound(string buttonName)
    {
        // ��ư�� �ش��ϴ� ȿ������ ���
        if (buttonSounds.TryGetValue(buttonName, out AudioClip soundClip))
        {
            audioSource.PlayOneShot(soundClip);
        }
    }
}
