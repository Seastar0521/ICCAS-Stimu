using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MusicPlayer : MonoBehaviour
{
    public AudioSource audioSrc;
    public Slider volumeSlider;

    private float musicVolume = 1f;

    void Start()
    {
        audioSrc.Play();
        musicVolume = PlayerPrefs.GetFloat("volume");
        audioSrc.volume = musicVolume;
        volumeSlider.value = musicVolume;
    }

    
    void Update()
    {
        audioSrc.volume = musicVolume;
        PlayerPrefs.SetFloat("volume",musicVolume);
    }

    public void updateVolume(float volume)
    {
        musicVolume = volume;
    }
   
    public void MusicReset()
    {
        PlayerPrefs.DeleteKey("volume");
        audioSrc.volume = 1;
        volumeSlider.value = 1;
    }
}
