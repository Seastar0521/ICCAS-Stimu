using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EfPlayer : MonoBehaviour
{
    public AudioSource audioSrc;

    private float efVolume = 1f;

    void Start()
    {
        audioSrc.Play();
    }

    // Update is called once per frame
    void Update()
    {
        audioSrc.volume = efVolume;
    }

    public void updateVolume(float volume)
    {
        efVolume = volume;
    }

}
