using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pause : MonoBehaviour
{
    public GameObject stopWindow;
    public void OnClickPause()
    {
        Time.timeScale = 0;
        stopWindow.SetActive(true);
        
    }

    // Update is called once per frame
    public void OnClickPauseBtn()
    {
        Time.timeScale = 1;
        stopWindow.SetActive(false);
    }
}
