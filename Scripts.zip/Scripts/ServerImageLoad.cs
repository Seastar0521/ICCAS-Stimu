using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class ServerImageLoad : MonoBehaviour
{

    public RawImage img;
    void Start()
    {
        
    }

    // Update is called once per frame
   
}
