using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartGameListener : MonoBehaviour
{

    private ScoreManager scoreManager;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void OnStartGame()
    {
        if (!ScoreManager.IsNull())
        {
            ScoreManager.Instance.DestroyScoreManager();
        }
        
        scoreManager = ScoreManager.Instance;

        SceneManager.LoadScene("LevelSelect");
    }
}
