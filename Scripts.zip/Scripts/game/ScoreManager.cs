using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Config;

public class ScoreManager : MonoBehaviour
{
    private static ScoreManager instance = null;
    private static string apiUrl = Config.Config.API_URL;
    private Dictionary<string, int> incorrectCounts;
    private GameInfoManager infoManager;
    private bool gameFinished = false;
    private Dictionary<string, bool> stageFinished;

    void Awake()
    {
        Debug.Log("ScoreManager.Awake() has been callen");
        Debug.Log("Instance: " + instance == null);            
        infoManager = GameInfoManager.Instance;
        StartCoroutine(infoManager.StartGame());
        ResetScores();
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);

        }
        else
        {
            if (this != instance)
            {
                Destroy(this.gameObject);
            }
        }
    }

    public static bool IsNull()
    {
        return instance == null;
    }

    public void DestroyScoreManager()
    {
        if (infoManager != null)
        {
            infoManager.DestroyGameInfoManager();
        }
        Destroy(this.gameObject);
        instance = null;
    }

    public static ScoreManager Instance
    {
        get
        {
            Debug.Log("ScoreManager Instance has been called");
            if (instance == null)
            {
                GameObject obj = new GameObject("ScoreManager");
                obj.AddComponent<ScoreManager>();
            }
            return instance;
        }
    }

    public void AddIncorrectCount(string level)
    {
        incorrectCounts[level] += 1;
    }

    public int GetIncorrectCount(string level)
    {
        return incorrectCounts[level];
    }

    public void ResetScores()
    {
        incorrectCounts = new Dictionary<string, int>();
        incorrectCounts.Add("Animal", 0);
        incorrectCounts.Add("Situation", 0);
        incorrectCounts.Add("Food", 0);
        incorrectCounts.Add("Number", 0);

        stageFinished = new Dictionary<string, bool>();
        stageFinished.Add("Animal", false);
        stageFinished.Add("Situation", false);
        stageFinished.Add("Food", false);
        stageFinished.Add("Number", false);
    }

    public bool IsStageFinished(string level)
    {
        return stageFinished[level];
    }

    public void CommitScores(string level)
    {
        stageFinished[level] = true;
        int currentScore = incorrectCounts[level];
        StartCoroutine(infoManager.SaveStageResult(level, currentScore, result => {
            if (result.gameFinished)
            {
                Debug.Log("Game finished");
                DestroyScoreManager();
            }
        }));
    }

    public string[] GetStageNames()
    {
        return incorrectCounts.Keys.ToArray<string>();
    }

    public void CommitScores()
    {
        foreach (KeyValuePair<string, int> items in incorrectCounts)
        {
            CommitScores(items.Key);
        }
    }

    public IEnumerator GetTotalScore(Action<int> callback)
    {
        yield return infoManager.GetTotalScore(callback);
    }
}
