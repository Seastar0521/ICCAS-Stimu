using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ScorePrinter : MonoBehaviour
{
    public Text scoreText;

    // Start is called before the first frame update
    void Start()
    {
        string sceneName = SceneManager.GetActiveScene().name;
        string pattern = "Stage(.*?)Score";

        ScoreManager scoreManager = ScoreManager.Instance;

        Match match = Regex.Match(sceneName, pattern);

        if (match.Success)
        {
            string level = match.Groups[1].Value;
            scoreManager.CommitScores(level);
            scoreText.text = "-" + scoreManager.GetIncorrectCount(level);
        }
    }
}
