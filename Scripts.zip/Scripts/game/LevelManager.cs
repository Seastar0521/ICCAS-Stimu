using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelManager : MonoBehaviour
{
    public Button[] levelButtons;

    private ScoreManager scoreManager;

    // Start is called before the first frame update
    void Awake()
    {
        Debug.Log("LevelManager is called");
        scoreManager = ScoreManager.Instance;

        for (int i = 0; i < levelButtons.Length; i++)
        {
            Debug.Log("level button name : " + levelButtons[i].name);
            Debug.Log("stage " + levelButtons[i].name + " finished : " + scoreManager.IsStageFinished(levelButtons[i].name));
           if ( scoreManager.IsStageFinished(levelButtons[i].name))
            {
                levelButtons[i].interactable = false;
            }
        }
    }

}
