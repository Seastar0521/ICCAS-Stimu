using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class SceneLoad : MonoBehaviour
{
    public Text LoadingText;
    private Authentication auth;

    public void Start()
    {
        Debug.Log("SceneLoad.Start() has been called");
        auth = Authentication.Instance;
        Debug.Log(auth == null ? "auth is null" : "auth is not null");
        StartCoroutine(auth.ValidateToken(result => {
            if (result)
            {
                SceneManager.LoadScene("Home");
            }
            else
            {
                SceneManager.LoadScene("Register");
            }
        }));
    }
}