using System.Collections;
using System.Collections.Generic;
using System;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;
using Config;

public class Authentication : MonoBehaviour
{
	private string apiUrl = Config.Config.API_URL;

	private static Authentication instance = null;

	void Awake()
	{
		if (instance == null) 
		{
			instance = this;
			DontDestroyOnLoad(this.gameObject);
		}
		else
		{
			if (this != instance)
			{
				Destroy(this.gameObject);
			}
		}
	}

	public static Authentication Instance
	{
		get
		{
			Debug.Log("Authentication Instance has been called");
			if (instance == null)
			{
				GameObject obj = new GameObject("Authentication");
				obj.AddComponent<Authentication>();
			}
			return instance;
		}
	}
	
	public IEnumerator AuthenticateUser(string username, string password, Action<bool> callback)
	{
		string url = apiUrl + "/auth/login";

		LoginData loginData = new LoginData(username, password);
		string bodyJson = JsonUtility.ToJson(loginData);

		using (UnityWebRequest www = new UnityWebRequest(url, "POST"))
		{
			byte[] bodyRaw = Encoding.UTF8.GetBytes(bodyJson);
			www.uploadHandler = new UploadHandlerRaw(bodyRaw);

			www.SetRequestHeader("Content-Type", "application/json");
			www.downloadHandler = new DownloadHandlerBuffer();

			yield return www.SendWebRequest();

			if (www.result == UnityWebRequest.Result.ConnectionError)
			{
				Debug.Log(www.error);
				callback(false);
			}
			else if (www.result == UnityWebRequest.Result.Success)
			{
				Debug.Log("Login successful!");
				TokenResponse response = JsonUtility.FromJson<TokenResponse>(www.downloadHandler.text);
				PlayerPrefs.SetString("accessToken", response.accessToken);
				PlayerPrefs.SetString("refreshToken", response.refreshToken);
				callback(true);
			}
			else
			{
				Debug.Log("Login Error: "+ www.error);
				callback(false);
			}
		}
	}

	public IEnumerator Registration(RegistrationData data, Action<bool> callback) 
	{
		string url = apiUrl + "/auth/registration";

		using (UnityWebRequest www = new UnityWebRequest(url, "POST"))
		{
			byte[] bodyRaw = Encoding.UTF8.GetBytes(JsonUtility.ToJson(data));
			www.uploadHandler = new UploadHandlerRaw(bodyRaw);
			www.SetRequestHeader("Content-Type", "application/json");

			yield return www.SendWebRequest();

			if (www.result == UnityWebRequest.Result.ConnectionError)
			{
				Debug.Log(www.error);
				callback(false);
			}
			else if (www.result == UnityWebRequest.Result.Success)
			{
				Debug.Log("Registration Succeed");
				callback(true);
			}
			else
			{
				Debug.Log("Registration Error");
				callback(false);
			}
		}
	}

	public IEnumerator ValidateToken(Action<bool> callback)
	{
		Debug.Log("ValidateToken has been called");
		string url = apiUrl + "/auth/validation";
		string accessToken = PlayerPrefs.GetString("accessToken");
		Debug.Log("accessToken: " + accessToken);
		
		if (accessToken == null)
		{
			Debug.Log("accessToken is null");
			callback(false);
		}

		using (UnityWebRequest www = new UnityWebRequest(url, "POST"))
		{
			byte[] bodyRaw = Encoding.UTF8.GetBytes(JsonUtility.ToJson(new ValidateRequest(accessToken)));
			www.uploadHandler = new UploadHandlerRaw(bodyRaw);
			www.SetRequestHeader("Content-Type", "application/json");
			www.downloadHandler = new DownloadHandlerBuffer();

			yield return www.SendWebRequest();

		if (www.result == UnityWebRequest.Result.ConnectionError)
		{
			Debug.Log("Connection Error");
			callback(false);
		}
		else if (www.result == UnityWebRequest.Result.Success)
		{
			Debug.Log("Response: " + www.downloadHandler.text);
			ValidateResponse response = JsonUtility.FromJson<ValidateResponse>(www.downloadHandler.text);
			if (response.validated)
			{
				callback(true);
			} else
			{
				callback(false);
			}
		}
		else
		{
			callback(false);
		}
		}
	}

	[System.Serializable]
    public class TokenResponse
    {
	    public string accessToken;
	    public string refreshToken;
    }

	[System.Serializable]
	public class LoginData
	{
		public string username;
		public string password;

		public LoginData(string username, string password)
		{
			this.username = username;
			this.password = password;
		}
	}

	[System.Serializable]
	public class ValidateRequest
	{
		public string accessToken;

		public ValidateRequest(string accessToken)
		{
			this.accessToken = accessToken;
		}
	}

	[System.Serializable]
	public class ValidateResponse
	{
		public bool validated;
	}

	[System.Serializable]
	public class RegistrationData
	{
		public string username;
		public string password;
		public string firstName;
		public string lastName;
		public string birthDay;
		public string dementiaLevel;

		public RegistrationData(string username, string password, string firstName, string lastName, string birthDay, string dementiaLevel)
		{
			this.username = username;
			this.password = password;
			this.firstName = firstName;
			this.lastName = lastName;
			this.birthDay = birthDay;
			this.dementiaLevel = dementiaLevel;
		}
	}
}