using System.Collections;
using System.Collections.Generic;
using System;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;
using Config;

public class GameInfoManager : MonoBehaviour
{
    private string apiUrl = Config.Config.API_URL;
    private static GameInfoManager instance = null;

    private string gameId = null;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
        }
        else
        {
            if (this != instance)
            {
                Destroy(this.gameObject);
            }
        }
    }

    public static GameInfoManager Instance
    {
        get
        {
            if (instance == null)
            {
                GameObject obj = new GameObject("GameInfoManager");
                obj.AddComponent<GameInfoManager>();
            }
            return instance;
        }
    }

    public void DestroyGameInfoManager()
    {
        Destroy(this.gameObject);
        instance = null;
    }

    public string GetCurrentGameId()
    {
        return gameId;
    }

    public IEnumerator StartGame()
    {
        string url = apiUrl + "/game/start";

        using (UnityWebRequest www = new UnityWebRequest(url, "POST"))
        {
            www.SetRequestHeader("Content-Type", "application/json");
            www.SetRequestHeader("Authorization", "Bearer " + PlayerPrefs.GetString("accessToken"));
            www.downloadHandler = new DownloadHandlerBuffer();

            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.ConnectionError)
            {
                Debug.Log(www.error);
            }
            else if (www.result == UnityWebRequest.Result.Success)
            {
                Debug.Log("Saving Score is succeed");
                GameStartResponseData response = JsonUtility.FromJson<GameStartResponseData>(www.downloadHandler.text);
                this.gameId = response.gameId;
            }
            else
            {
                Debug.Log("Failed");
            }
        }
    }

    public IEnumerator GetTotalScore(Action<int> callback)
    {
        string url = apiUrl + "/game/score?gameId=" + gameId;
        Debug.Log("gameId : " + gameId);

        using (UnityWebRequest www = new UnityWebRequest(url, "GET"))
        {
            www.SetRequestHeader("Content-Type", "application/json");
            www.SetRequestHeader("Authorization", "Bearer " + PlayerPrefs.GetString("accessToken"));
            www.downloadHandler = new DownloadHandlerBuffer();

            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.ConnectionError)
            {
                Debug.Log(www.error);
                callback(0);
            }
            else if (www.result == UnityWebRequest.Result.Success)
            {
                Debug.Log("Saving Score is succeed");
                ScoreData response = JsonUtility.FromJson<ScoreData>(www.downloadHandler.text);
                callback(response.score);
            }
            else
            {
                Debug.Log("Failed");
                callback(0);
            }

        }
    }

    public IEnumerator SaveStageResult(string level, int incorrectCount, Action<SaveStageResultResponseData> callback)
    {
        string url = apiUrl + "/stage/result";

        SaveStageResultRequestData body = new SaveStageResultRequestData(gameId, level, incorrectCount);
        string bodyJson = JsonUtility.ToJson(body);

        using (UnityWebRequest www = new UnityWebRequest(url, "POST"))
        {
            byte[] bodyRaw = Encoding.UTF8.GetBytes(bodyJson);
            www.uploadHandler = new UploadHandlerRaw(bodyRaw);
            www.SetRequestHeader("Content-Type", "application/json");
            www.SetRequestHeader("Authorization", "Bearer " + PlayerPrefs.GetString("accessToken"));
            www.downloadHandler = new DownloadHandlerBuffer();

            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.ConnectionError)
            {
                Debug.Log(www.error);
                callback(null);
            }
            else if (www.result == UnityWebRequest.Result.Success)
            {
                Debug.Log("Saving Score is succeed");
                SaveStageResultResponseData response = JsonUtility.FromJson<SaveStageResultResponseData>(www.downloadHandler.text);
                callback(response);
            }
            else
            {
                Debug.Log("Failed");
                callback(null);
            }
        }
    }

    [System.Serializable]
    public class SaveStageResultRequestData
    {
        public string gameId;
        public string stage;
        public int incorrectCount;

        public SaveStageResultRequestData(string gameId, string stage, int incorrectCount)
        {
            this.gameId = gameId;
            this.stage = stage.ToUpper();
            this.incorrectCount = incorrectCount;
        }
    }

    [System.Serializable]
    public class ScoreData
    {
        public string gameId;
        public int score;
    }

    [System.Serializable]
    public class SaveStageResultResponseData
    {
        public string gameId;
        public bool gameFinished;
    }

    [System.Serializable]
    public class GameStartResponseData
    {
        public string gameId;
        public string createTime;
    }
}
