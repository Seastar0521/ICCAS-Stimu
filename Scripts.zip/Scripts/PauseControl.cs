/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseControl : MonoBehaviour
{
    [SerializeField] TextAlignment startPauseText;
    bool pauseActive = false;

    public void pauseBtn()
    {
        if (pauseActive)
        {
            Time.timeScale = 1;
            pauseActive = false;
        }
        else
        {
            Time.timeScale = 0;
            pauseActive = true;
        }

        startPauseText.text = pauseActive ? "START" : "PAUSE";
    }
}*/
