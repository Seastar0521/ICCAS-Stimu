using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Text12 : MonoBehaviour
{
    int a = 5;
    public UnityEngine.UI.Text mainText;

    public void myOnClick()
    {
        mainText.text = "Which color is Red?";
    }

    void Start()
    {
        mainText.text = "Which color is Orange?";
    }

}

