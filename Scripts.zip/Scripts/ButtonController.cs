using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonController : MonoBehaviour
{
    public void OnStageButtonClicked()
    {
        // stage 버튼이 클릭되었을 때의 동작
        Debug.Log("Try again!");
    }

    public void OnStage1ButtonClicked()
    {
        // stage (1) 버튼이 클릭되었을 때의 동작
        SceneManager.LoadScene("level 1-2");
    }

}
