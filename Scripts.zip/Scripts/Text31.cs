using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Text31 : MonoBehaviour
{
    int a = 5;
    public UnityEngine.UI.Text mainText;

    public void myOnClick()
    {
        mainText.text = "Which number is bigger ?";
    }

    void Start()
    {
        mainText.text = "Level 3 is a stage of number.\r\nChoose the number,\r\nwhich is bigger than the others.";
    }

}
