using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BtnType : MonoBehaviour
{
    public GameObject Pause;

    public void OnClickStopBtn()
    {
        Time.timeScale = 0;
        Pause.SetActive(true); 

    }

    public void OnClickContinBtn()
    {
        Time.timeScale = 1;
        Pause.SetActive(false);
    }
   
}
