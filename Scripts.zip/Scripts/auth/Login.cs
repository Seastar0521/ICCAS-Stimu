using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Login : MonoBehaviour
{
    public GameObject LoginView;

    public InputField UsernameInput;
    public InputField PasswordInput;
    public Button LoginButton;
    private Authentication Auth;

    // Start is called before the first frame update
    void Start()
    {
        Auth = Authentication.Instance;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnLoginButtonClick()
    {
        StartCoroutine(Auth.AuthenticateUser(UsernameInput.text, PasswordInput.text, result => {
            if (result) {
                Debug.Log("로그인 성공");
                SceneManager.LoadScene("Home");
            } else {
                Debug.Log("로그인 실패");
                AndroidToast.I.ShowToastMessage("로그인에 실패했습니다.");
            }
        }));
        
    }
}
