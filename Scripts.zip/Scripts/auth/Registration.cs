using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UI.Dates;

public class Registration : MonoBehaviour
{
    public GameObject registrationView;
    public InputField usernameInput;
    public InputField passwordInput;
    public InputField firstNameInput;
    public InputField lastNameInput;
    public Dropdown dementiaLevelDropdown;
    public Button submitButton;
    public string[] dementiaLevels = new string[] {"NORMAL", "MILD_COGNITIVE_IMPAIRMENT", "MODERATE_DEMENTIA"};
    [SerializeField]
    public DatePicker datePicker;

    private Authentication auth;
    private string dementiaLevel;

    // Start is called before the first frame update
    void Start()
    {
        auth = Authentication.Instance;
        dementiaLevelDropdown.onValueChanged.AddListener(DropdownValueChanged);
        dementiaLevel = dementiaLevels[0];
    }

    void DropdownValueChanged(int index)
    {
        dementiaLevel = dementiaLevels[index];
        Debug.Log("선택된 치매 단계: " + dementiaLevel);
    }

    public void OnSubmitButtonClick()
    {
        StartCoroutine(auth.Registration(new Authentication.RegistrationData (
            usernameInput.text,
            passwordInput.text,
            firstNameInput.text,
            lastNameInput.text,
            datePicker.SelectedDate.Date.ToString("yyyy-MM-dd"),
            dementiaLevel
            ), result => {
                if (result)
                {
                    Debug.Log("Registration Succeed");
                    SceneManager.LoadScene("Register");
                } else {
                    AndroidToast.I.ShowToastMessage("회원가입 실패");
                }
            }));
            
    }
}
