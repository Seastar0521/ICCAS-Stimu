using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Text41 : MonoBehaviour
{
   
    int a = 5;
    public UnityEngine.UI.Text mainText;

    public void myOnClick()
    {
        mainText.text = "Which food is Cheese ?";
    }

    void Start()
    {
        mainText.text = "Level 4 is a stage of food.\r\nChoose the food,\r\nwhich matches with the name.";
    }

}
