using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Text51 : MonoBehaviour
{
    int a = 5;
    public UnityEngine.UI.Text mainText;

    public void myOnClick()
    {
        mainText.text = "Which animal is rabbit ?";
    }

    void Start()
    {
        mainText.text = "Level 5 is a stage of animal.\r\nChoose the animal,\r\nwhich matches with the name.";
    }

}
