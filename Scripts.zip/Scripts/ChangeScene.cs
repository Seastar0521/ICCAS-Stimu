using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeScene : MonoBehaviour
{

    public void ChangeSceneBtn()
    {
        switch (this.gameObject.name)
        {
            case "Start1":
                SceneManager.LoadScene("Login");
                break;
            case "OK":
                SceneManager.LoadScene("LevelSelect");
                break;
            case "Option":
                SceneManager.LoadScene("Option");
                break;
            case "Home":
                SceneManager.LoadScene("Home");
                break;
            case "Level1":
                SceneManager.LoadScene("Level 1-1");
                break;
            case "Level2":
                SceneManager.LoadScene("Level 2-1");
                break;
            case "Level3":
                SceneManager.LoadScene("Level 3-1");
                break;
            case "Level4":
                SceneManager.LoadScene("Level 4-1");
                break;
            case "Level5":
                SceneManager.LoadScene("Level 5-1");
                break;
            case "Level6":
                SceneManager.LoadScene("Level 6-1");
                break;
            case "Pause":
                SceneManager.LoadScene("Pause");
                break;
            case "Resume":
                SceneManager.LoadScene("  ");
                break;
            case "Sound":
                SceneManager.LoadScene("Sound");
                break;
            case "Quit":
                SceneManager.LoadScene("Home");
                break;
            case "End":
                SceneManager.LoadScene("LevelSelect");
                break;
            case "Next 1-1":
                SceneManager.LoadScene("Level 1-2");
                break;
            case "Next 1-2":
                SceneManager.LoadScene("Level 1-3");
                break;
            case "Next 1-3":
                SceneManager.LoadScene("Level 1-4");
                break;
            case "Next 1-4":
                SceneManager.LoadScene("Level 1-5");
                break;
            case "Next 1-5":
                SceneManager.LoadScene("Level 1-6");
                break;
            case "Next 1-6":
                SceneManager.LoadScene("Level 1-7");
                break;
            case "Next 2-1":
                SceneManager.LoadScene("Level 2-2");
                break;
            case "Next 2-2":
                SceneManager.LoadScene("Level 2-3");
                break;
            case "Next 2-3":
                SceneManager.LoadScene("Level 2-4");
                break;
            case "Next 2-4":
                SceneManager.LoadScene("Level 2-5");
                break;
            case "Next 2-5":
                SceneManager.LoadScene("Level 2-6");
                break;
            case "Next 2-6":
                SceneManager.LoadScene("Level 2-7");
                break;
            case "Next 3-1":
                SceneManager.LoadScene("Level 3-2");
                break;
            case "Next 3-2":
                SceneManager.LoadScene("Level 3-3");
                break;
            case "Next 3-3":
                SceneManager.LoadScene("Level 3-4");
                break;
            case "Next 3-4":
                SceneManager.LoadScene("Level 3-5");
                break;
            case "Next 3-5":
                SceneManager.LoadScene("Level 3-6");
                break;
            case "Next 3-6":
                SceneManager.LoadScene("Level 3-7");
                break;
            case "Next 4-1":
                SceneManager.LoadScene("Level 4-2");
                break;
            case "Next 4-2":
                SceneManager.LoadScene("Level 4-3");
                break;
            case "Next 4-3":
                SceneManager.LoadScene("Level 4-4");
                break;
            case "Next 4-4":
                SceneManager.LoadScene("Level 4-5");
                break;
            case "Next 4-5":
                SceneManager.LoadScene("Level 4-6");
                break;
            case "Next 4-6":
                SceneManager.LoadScene("Level 4-7");
                break;
            case "Next 5-1":
                SceneManager.LoadScene("Level 5-2");
                break;
            case "Next 5-2":
                SceneManager.LoadScene("Level 5-3");
                break;
            case "Next 5-3":
                SceneManager.LoadScene("Level 5-4");
                break;
            case "Next 5-4":
                SceneManager.LoadScene("Level 5-5");
                break;
            case "Next 5-5":
                SceneManager.LoadScene("Level 5-6");
                break;
            case "Next 5-6":
                SceneManager.LoadScene("Level 5-7");
                break;
            case "Next 6-1":
                SceneManager.LoadScene("Level 6-2");
                break;
            case "Next 6-2":
                SceneManager.LoadScene("Level 6-3");
                break;
            case "Next 6-3":
                SceneManager.LoadScene("Level 6-4");
                break;
            case "Next 6-4":
                SceneManager.LoadScene("Level 6-5");
                break;
            case "Next 6-5":
                SceneManager.LoadScene("Level 6-6");
                break;
            case "Next 6-6":
                SceneManager.LoadScene("Level 6-7");
                break;

        }
    }
}
