using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeScene : MonoBehaviour
{

    public void ChangeSceneBtn()
    {
        switch (this.gameObject.name)
        {
            case "Start":
                SceneManager.LoadScene("LevelSelect");
                break;
            case "Option":
                SceneManager.LoadScene("Option");
                break;
            case "Home":
                SceneManager.LoadScene("Home");
                ScoreManager.Instance.DestroyScoreManager();
                break;
            case "Number":
                SceneManager.LoadScene("Number 1");
                break;
            case "Situation":
                SceneManager.LoadScene("Situation 1");
                break;
            case "Food":
                SceneManager.LoadScene("Food 1");
                break;
            case "Animal":
                SceneManager.LoadScene("Animal 1");
                break;
            case "NextLevel1":
                SceneManager.LoadScene("Situation 1");
                break;
            case "NextLevel2":
                SceneManager.LoadScene("Food 1");
                break;
            case "NextLevel3":
                SceneManager.LoadScene("Animal 1");
                break;
            case "Pause":
                SceneManager.LoadScene("Pause");
                GameManager.instance.SetPreviousScene();    
                break;
            case "Restart":
                SceneManager.LoadScene("Home");
                break;
            case "Resume":
                GameManager.instance.LoadPreviousScene();
                break;
            case "Sound":
                SceneManager.LoadScene("Sound");
                break;
            case "Exit":
                SceneManager.LoadScene("Home");
                break;
            case "End":
                string sceneName = SceneManager.GetActiveScene().name;
                string levelString = sceneName.Split(' ')[0];
                SceneManager.LoadScene("Stage" + levelString + "Score");
                break;
            case "Next 1-1":
                SceneManager.LoadScene("Number 2");
                break;
            case "Next 1-2":
                SceneManager.LoadScene("Number 3");
                break;
            case "Next 1-3":
                SceneManager.LoadScene("Number 4");
                break;
            case "Next 1-4":
                SceneManager.LoadScene("Number 5");
                break;
            case "Next 1-5":
                SceneManager.LoadScene("Number 6");
                break;
            case "Next 1-6":
                SceneManager.LoadScene("Number 7");
                break;
            case "Next 1-7":
                SceneManager.LoadScene("Stage1Score");
                break;

            case "Next 2-1":
                SceneManager.LoadScene("Situation 2");
                break;
            case "Next 2-2":
                SceneManager.LoadScene("Situation 3");
                break;
            case "Next 2-3":
                SceneManager.LoadScene("Situation 4");
                break;
            case "Next 2-4":
                SceneManager.LoadScene("Situation 5");
                break;
            case "Next 2-5":
                SceneManager.LoadScene("Situation 6");
                break;
            case "Next 2-6":
                SceneManager.LoadScene("Situation 7");
                break;
            case "Next 2-7":
                SceneManager.LoadScene("Situation 8");
                break;
            case "Next 2-8":
                SceneManager.LoadScene("Situation 9");
                break;
            case "Next 2-9":
                SceneManager.LoadScene("Situation 10");
                break;
            case "Next 2-10":
                SceneManager.LoadScene("Stage2Score");
                break;

            case "Next 3-1":
                SceneManager.LoadScene("Food 2");
                break;
            case "Next 3-2":
                SceneManager.LoadScene("Food 3");
                break;
            case "Next 3-3":
                SceneManager.LoadScene("Food 4");
                break;
            case "Next 3-4":
                SceneManager.LoadScene("Food 5");
                break;
            case "Next 3-5":
                SceneManager.LoadScene("Food 6");
                break;
            case "Next 3-6":
                SceneManager.LoadScene("Food 7");
                break;
            case "Next 3-7":
                SceneManager.LoadScene("Stage3Score");
                break;

            case "Next 4-1":
                SceneManager.LoadScene("Animal 2");
                break;
            case "Next 4-2":
                SceneManager.LoadScene("Animal 3");
                break;
            case "Next 4-3":
                SceneManager.LoadScene("Animal 4");
                break;
            case "Next 4-4":
                SceneManager.LoadScene("Animal 5");
                break;
            case "Next 4-5":
                SceneManager.LoadScene("Animal 6");
                break;
            case "Next 4-6":
                SceneManager.LoadScene("Animal 7");
                break;
            case "Next 4-7":
                SceneManager.LoadScene("Stage4Score");
                break;
            
            case "ChatBot":
                SceneManager.LoadScene("ChatGPT");
                break;
            case "NextLevel":
                SceneManager.LoadScene("LevelSelect");
                break;
            case "NextLevel5":
                SceneManager.LoadScene("FinalScore");
                break;
            case "NextLevelFinal":
                SceneManager.LoadScene("Home");
                break;

        }
    }
}
