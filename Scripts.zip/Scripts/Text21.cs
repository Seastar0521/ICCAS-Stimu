using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Text21 : MonoBehaviour
{
    int a = 5;
    public UnityEngine.UI.Text mainText;

    public void myOnClick()
    {
        mainText.text = "Which shape is circle ?";
    }

    void Start()
    {
        mainText.text = "Level 2 is a stage of shape.\r\nChoose the shape,\r\nwhich is written in the given question.";
    }

}

