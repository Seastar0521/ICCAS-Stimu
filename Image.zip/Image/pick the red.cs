using UnityEngine;
using UnityEngine.UI;

public class BalloonController : MonoBehaviour
{
    public Text text;

    private void Start()
    {
        // 말풍선에 표시할 글자 설정
        text.text = "Pick the Red Button!";
    }
}
